import javax.swing.*;
import java.awt.event.*;

public class SimpleCalculator {
    public static void main(String[] args) {
        JFrame f = new JFrame("Simple Calculator");
        JTextField t1 = new JTextField();
        JTextField t2 = new JTextField();
        JButton add = new JButton("+");
        JButton sub = new JButton("-");
        JButton mul = new JButton("*");
        JButton div = new JButton("/");

        t1.setBounds(30, 30, 100, 30);
        t2.setBounds(150, 30, 100, 30);
        add.setBounds(30, 80, 50, 30);
        sub.setBounds(90, 80, 50, 30);
        mul.setBounds(150, 80, 50, 30);
        div.setBounds(210, 80, 50, 30);

        ActionListener calc = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    double a = Double.parseDouble(t1.getText());
                    double b = Double.parseDouble(t2.getText());
                    String op = e.getActionCommand();
                    double result = 0;
                    if (op.equals("+")) result = a + b;
                    else if (op.equals("-")) result = a - b;
                    else if (op.equals("*")) result = a * b;
                    else if (op.equals("/")) {
                        if (b == 0) {
                            JOptionPane.showMessageDialog(f, "Cannot divide by zero");
                            return;
                        }
                        result = a / b;
                    }
                    JOptionPane.showMessageDialog(f, "Result: " + result);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(f, "Enter valid numbers");
                }
            }
        };
        add.addActionListener(calc);
        sub.addActionListener(calc);
        mul.addActionListener(calc);
        div.addActionListener(calc);

        f.add(t1); f.add(t2); f.add(add); f.add(sub); f.add(mul); f.add(div);
        f.setSize(300, 170);
        f.setLayout(null);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);
    }
}
