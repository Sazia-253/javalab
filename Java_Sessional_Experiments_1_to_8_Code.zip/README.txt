Java Sessional Experiments 1–8
Each .java file is named to match its public class.
Compile: javac FileName.java
Run: java ClassName
Experiment 1 requires pic.jpg in the program's working directory.
Note: Experiment 5 uses safer pause/resume/stop methods; Experiment 7 includes deprecated/unsafe Thread.stop() only as a syllabus demonstration.
