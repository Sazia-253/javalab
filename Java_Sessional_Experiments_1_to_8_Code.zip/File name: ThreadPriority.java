class ThreadPriority extends Thread {
    ThreadPriority(String name, int priority) {
        setName(name);
        setPriority(priority);
    }

    public void run() {
        for (int i = 1; i <= 3; i++) {
            System.out.println(getName() + ": " + i);
        }
    }

    public static void main(String[] args) {
        ThreadPriority t1 = new ThreadPriority("Low", 1);
        ThreadPriority t2 = new ThreadPriority("Normal", 5);
        ThreadPriority t3 = new ThreadPriority("High", 10);
        t1.start();
        t2.start();
        t3.start();
    }
}
