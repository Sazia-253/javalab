import javax.swing.*;
import java.awt.event.*;

public class StudentForm {
    public static void main(String[] args) {
        JFrame f = new JFrame("Student Form");
        JLabel l1 = new JLabel("Name:");
        JLabel l2 = new JLabel("ID:");
        JLabel l3 = new JLabel("Department:");
        JTextField t1 = new JTextField();
        JTextField t2 = new JTextField();
        JTextField t3 = new JTextField();
        JButton b = new JButton("Submit");

        l1.setBounds(30, 30, 100, 30);
        t1.setBounds(130, 30, 150, 30);
        l2.setBounds(30, 70, 100, 30);
        t2.setBounds(130, 70, 150, 30);
        l3.setBounds(30, 110, 100, 30);
        t3.setBounds(130, 110, 150, 30);
        b.setBounds(90, 160, 100, 30);

        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(f,
                    "Name: " + t1.getText() +
                    "\\nID: " + t2.getText() +
                    "\\nDepartment: " + t3.getText());
            }
        });

        f.add(l1); f.add(t1); f.add(l2); f.add(t2);
        f.add(l3); f.add(t3); f.add(b);
        f.setSize(350, 250);
        f.setLayout(null);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);
    }
}
