import javax.swing.*;

public class DisplayImage {
    public static void main(String[] args) {
        JFrame f = new JFrame("Display Image");
        ImageIcon img = new ImageIcon("pic.jpg");
        JLabel label = new JLabel(img);
        f.add(label);
        f.setSize(500, 400);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);
    }
}
