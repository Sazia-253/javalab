import javax.swing.*;
import java.awt.event.*;

public class RestaurantBill {
    public static void main(String[] args) {
        JFrame f = new JFrame("Restaurant Bill");
        JLabel l1 = new JLabel("Food Name:");
        JLabel l2 = new JLabel("Price:");
        JLabel l3 = new JLabel("Quantity:");
        JTextField t1 = new JTextField();
        JTextField t2 = new JTextField();
        JTextField t3 = new JTextField();
        JButton b = new JButton("Calculate Bill");

        l1.setBounds(30, 30, 100, 30);
        t1.setBounds(130, 30, 150, 30);
        l2.setBounds(30, 70, 100, 30);
        t2.setBounds(130, 70, 150, 30);
        l3.setBounds(30, 110, 100, 30);
        t3.setBounds(130, 110, 150, 30);
        b.setBounds(90, 160, 150, 30);

        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    String food = t1.getText();
                    double price = Double.parseDouble(t2.getText());
                    int qty = Integer.parseInt(t3.getText());
                    double total = price * qty;
                    JOptionPane.showMessageDialog(f,
                        "Food: " + food +
                        "\\nTotal Bill: " + total + " Taka");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(f,
                        "Enter valid price and quantity!");
                }
            }
        });

        f.add(l1); f.add(t1); f.add(l2); f.add(t2);
        f.add(l3); f.add(t3); f.add(b);
        f.setSize(350, 260);
        f.setLayout(null);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);
    }
}
