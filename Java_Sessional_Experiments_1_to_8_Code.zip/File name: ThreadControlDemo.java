class MyThread extends Thread {
    private boolean paused = false;
    private boolean stopped = false;

    synchronized void pauseThread() {
        paused = true;
    }
    synchronized void resumeThread() {
        paused = false;
        notify();
    }
    synchronized void stopThread() {
        stopped = true;
        paused = false;
        notify();
    }

    public void run() {
        int i = 1;
        while (true) {
            synchronized (this) {
                if (stopped) break;
                while (paused && !stopped) {
                    try { wait(); } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                }
                if (stopped) break;
            }
            System.out.println("Count: " + i++);
            try { Thread.sleep(500); } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
        }
        System.out.println("Thread stopped");
    }
}

public class ThreadControlDemo {
    public static void main(String[] args) throws Exception {
        MyThread t = new MyThread();
        t.start();
        Thread.sleep(1500);
        t.pauseThread();
        System.out.println("Paused");
        Thread.sleep(1500);
        t.resumeThread();
        System.out.println("Resumed");
        Thread.sleep(1500);
        t.stopThread();
    }
}
