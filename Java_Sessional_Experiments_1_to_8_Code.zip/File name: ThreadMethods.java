class MyThread extends Thread {
    public void run() {
        for (int i = 1; i <= 10; i++) {
            System.out.println(i);
            Thread.yield();
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                return;
            }
        }
    }
}

public class ThreadMethods {
    public static void main(String[] args) {
        MyThread t = new MyThread();
        t.start();
        try {
            Thread.sleep(2000);
            t.stop(); // deprecated/unsafe; only for syllabus demonstration
            System.out.println("Stopped");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
